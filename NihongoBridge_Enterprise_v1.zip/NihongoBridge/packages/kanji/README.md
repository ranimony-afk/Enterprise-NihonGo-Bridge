# Kanji study models

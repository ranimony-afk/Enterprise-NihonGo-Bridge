# Separate AI Infrastructure layer
